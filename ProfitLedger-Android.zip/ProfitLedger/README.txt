دفتر الأرباح - مشروع Android Studio

الخطوات:
1) افتح Android Studio ثم File > Open واختر مجلد ProfitLedger.
2) انتظر انتهاء Gradle Sync (يحتاج إنترنت أول مرة). لو طلب تثبيت Android SDK 34 اقبل.
   لو اقترح تحديث Gradle أو Android Gradle Plugin وافق عليه.
3) من القائمة: Build > Build Bundle(s) / APK(s) > Build APK(s).
4) بعد الانتهاء اضغط Locate في الإشعار، أو افتح:
   app/build/outputs/apk/debug/app-debug.apk
5) انسخ الملف إلى الهاتف وافتحه وثبّته (فعّل "التثبيت من مصادر غير معروفة" إن طُلب).

ملاحظات:
- الصفحة داخل المشروع في app/src/main/assets/index.html وتعمل بدون إنترنت.
- البيانات تُحفظ داخل التطبيق. حذف التطبيق أو مسح بياناته يمسحها.
- من الإعدادات داخل التطبيق: "حفظ نسخة احتياطية" تحفظ ملفًا في مجلد التنزيلات، و"استرجاع نسخة احتياطية" تعيد البيانات منه.
- لتغيير اسم الحزمة (com.example.profitledger) عدّل applicationId في app/build.gradle.
